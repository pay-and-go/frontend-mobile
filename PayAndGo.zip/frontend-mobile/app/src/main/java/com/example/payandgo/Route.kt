package com.example.payandgo

data class Route(val startCity: String, val arrivalCity: String, val description: String)
